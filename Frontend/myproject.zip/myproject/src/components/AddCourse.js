//import axios from "axios";
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";
import CourseService from "../Service/CourseService";


const AddCourse = () => {
    const[courseName, setcourseName] = useState('');
    const [startDate, setstartDate] = useState('');
    const [endDate, setendDate] = useState('');

    const navigate = useNavigate();
    const {id} = useParams();


    
    const saveCourse = (c) => {
        c.preventDefault();
        
        const course = {courseName, startDate,endDate,id};
        if (id) {
            //update
            console.log(course);
            CourseService.update(id,course)
                .then(response => {
                    console.log('Course data updated successfully', response.data);
                    navigate('/listcourse');
                })
                .catch(error => {
                    alert(error.response.status);
                    console.log("Error code "+error);
                    console.log('Something went wrong', error.response.data);
                   
                }) 
        } else {
            //create
            console.log(course);
             CourseService.create(course)
            .then(response => {
                console.log("Course added successfully", response.data);
                navigate("/listcourse");
            })
            .catch(error => {
                // console.log(error.response.data);
                // alert(error.response.data.Worklocation);
                // console.log(error.response.headers)
                // console.log(error.response.status);
                console.log('something went wrong'+ error.response);
            })
        }
    }

    useEffect(() => {
        if (id) {
            CourseService.get(id)
                .then(course => {
                    setcourseName(course.data.courseName);
                    setstartDate(course.data.startDate);
                    setendDate(course.data.endDate);
                    
                   
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                })
        }
    }, 
    [])
    return(
        <div className="container">
            <h3>Add Course</h3>
             
            <hr/>
            {/*
            <form style={{'width':'500px'}}>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="courseName"
                        value={courseName}
                        onChange={(e) => setcourseName(e.target.value)}
                        placeholder="Enter Course Name"
                    />

                </div>

                <div className="mb-3">
                    
                    <input 
                        type="date" 
                        className="form-control col-4"
                        id="startDate"
                        value={startDate}
                        onChange={(e) => setstartDate(e.target.value)}
                        placeholder="Enter Start Date"
                    />
                </div>
                <div className="mb-3">
                    <input 
                        type="date" 
                        className="form-control col-4"
                        id="endDate"
                        value={endDate}
                        onChange={(e) => setendDate(e.target.value)}
                        placeholder="Enter End Date"
                    />
                </div>
                   
                <div >
                    <button onClick={(c) => saveCourse(c)} className="btn btn-warning btn-lg">Save</button>
                </div>
            </form>
            */}
             <form>
          
          {/*
          <select class="form-select form-select-sm mb-3" aria-label="form-select-sm example"
             onChange={e=>setRole(e.target.value)}
          >
  <option selected>Select Role</option>
  <option value="admin">Admin</option>
  <option value="mentor">Mentor</option>
  <option value="student">Student</option>
</select>
          */}
         
     {/* <!-- Email input --> */}
      <div class="form-outline mb-4">
      <label class="form-label" for="">Enter Course Name</label><br></br>
       {/* <input type="text" id="" name="" value={userEmail}  onChange={e=>setEmail(e.target.value)} placeholder="Enter Email" class="form-control-lg" /> */}
        <input 
                        type="text" 
                        className="form-control-lg"
                        id="courseName"
                        value={courseName}
                        onChange={(e) => setcourseName(e.target.value)}
                        placeholder="Enter Course Name"
                    />
        
      </div>
    
     {/* <!-- Password input --> */}
      <div class="form-outline mb-4">
      <label class="form-label " for="">Enter Start Date</label><br></br>
        {/*   <input type="password" id="" name="password" value={userPassword} onChange={e=>setPassword(e.target.value)} placeholder="Enter Password" class=" form-control-lg" /> */}
        <input 
                        type="date" 
                        className="form-control-lg"
                        id="startDate"
                        value={startDate}
                        onChange={(e) => setstartDate(e.target.value)}
                        placeholder="Enter Start Date"
                    />
        
      </div>
      <div class="form-outline mb-4">
      <label class="form-label" for="">Enter End Date</label><br></br>
        {/*   <input type="password" id="" name="password" value={userPassword} onChange={e=>setPassword(e.target.value)} placeholder="Enter Password" class=" form-control-lg" /> */}
        <input 
                        type="date" 
                        className="form-control-lg"
                        id="startDate"
                        value={endDate}
                        onChange={(e) => setendDate(e.target.value)}
                        placeholder="Enter end Date"
                    />
        
      </div>
    

     {/* <!-- 2 column grid layout for inline styling --> */}
     {/* */}
      <div class="row mb-4">
        <div class="col d-flex justify-content-center">
         {/* <!-- Checkbox --> */} 
          
        </div>
        
    {/*
        <div class="col">
        
          <a href="#!">Forgot password?</a>
        </div>
    */}
      </div>
    
      <div >
                    <button onClick={(c) => saveCourse(c)} className="btn btn-warning btn-lg">Save</button>
                </div>
    </form>
            <hr/>
            <Link to="/listcourse">Back to List</Link> &emsp;&emsp;&emsp;&emsp;{/*<Link to={`/welcome`}>&emsp;&emsp;<button className='btn btn-warning btn-lg'>Go to Welcome Page</button></Link> */}
        </div>
    )
}

export default AddCourse;