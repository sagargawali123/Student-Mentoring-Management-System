import { useState } from "react";
import { AxiosProvider, Get } from "react-axios";
import { useNavigate,Link } from "react-router-dom";
import { useHistory } from 'react-router';
import ReactTooltip from "react-tooltip";
import AuthenticateSevice from "../Service/AuthenticationService";

const Register=()=>{
    const [userFirstName,setuserFirstName] = useState('');
    const [userLastName,setuserLastName] = useState('');
    const [userEmail,setuserEmail] = useState('');
    const [userPassword, setuserPassword] = useState('');
    const[userMoNo,setuserMoNo]=useState('');
    const[regDate,setregDate]=useState('');
    const[userRole,setuserRole]=useState('');
    const navigate = useNavigate();
  //  const history=useHistory();
   // const [User, setUser] = useState(false);
    const [admin, setAdmin] = useState(false);
    const [student, setStudent] = useState(false);
    const[mentor,setMentor]=useState(false);
   //  const userRole = ['ADMIN','STUDENT','MENTOR'];
    //    const roles='admin'
    function toggle(value){
        return !value;
      }

    const handleChange=(event)=>{
        const arr =[];
            if(userRole.includes(event.target.value))
            return;
                userRole.forEach(r=>arr.push(r));
                arr.push(event.target.value);
                setuserRole(arr);
            
            
    }
    
    

    const handleSubmit=()=>{
      //  if(User===true)
      //  roles.push("ROLE_USER");
        if(userRole == "admin")
    //   userRole.push("admin")
        if(userRole == "student")
     //   userRole.push("student");
        if(userRole == "mentor")
      //  userRole.push("mentor");

        console.log(userRole);
        const user ={userFirstName,userLastName,userEmail,userPassword,userMoNo,regDate,userRole}
        AuthenticateSevice.registerUser(user).then(response=>{alert("Success",JSON.stringify(response.data));navigate(`/`)}).catch(error=>{alert("error, Something went wrong");setuserRole([])});

       
    }

    return(
        <form>
            <hr></hr>
        
        <div class="form-outline mb-1">
            <label class="form-label" htmlFor="">User First Name &emsp; </label><input type="text" name="userFirstName" id="" onChange={e=>setuserFirstName(e.target.value)} value={userFirstName}/><br></br>
            </div>
            <div class="form-outline mb-1">
            <label class="form-label" htmlFor="">User Last Name &emsp; </label><input type="text" name="userLastName" id="" onChange={e=>setuserLastName(e.target.value)} value={userLastName}/><br></br>
            </div>
            <div class="form-outline mb-1">
            <label class="form-label" htmlFor="">Email : &emsp; &emsp; &emsp; &emsp;</label><input type="email" name="email" id="" onChange={e=>setuserEmail(e.target.value)} value={userEmail} /><br></br>
            </div>
            <div class="form-outline mb-1">
            <label class="form-label" htmlFor="">Password : &emsp;&emsp;&emsp;</label><input type="password" name="password" id="" onChange={e=>setuserPassword(e.target.value)} value={userPassword} /><br></br>
            </div>
            <div class="form-outline mb-1">
            <label class="form-label" htmlFor="">Mobile No : &emsp;&emsp;</label><input type="number" name="monumber" id="" onChange={e=>setuserMoNo(e.target.value)} value={userMoNo}/><br></br>
            </div>
            <div class="form-outline mb-1">
            <label class="form-label" htmlFor="">Reg Date : &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</label><input type="date" name="regdate" id="" onChange={e=>setregDate(e.target.value)} value={regDate}/><br></br><br></br>
            </div>
           {/* <p style={{'backgroundColor':'skyblue','width':'400px','alignContent':'center','marginLeft':'500px'}}>Select  Role</p> */}
           <div><h4>Select Role</h4></div>
          {/*
            <label htmlFor="ad">Admin</label>&emsp; <input type="checkbox" name="role" value='admin' onChange={()=>setAdmin(toggle)} id="ad" /><br></br>
        
            <label htmlFor="sd">Student</label>&emsp;<input type="checkbox" name="role" value='student' onChange={()=>setStudent(toggle)} id="sd" /><br></br><br></br>
            <label htmlFor="me">Mentor</label>&emsp;&emsp;<input type="checkbox" name="role" value='mentor' onChange={()=>setMentor(toggle)} id="me" /><br></br>
          */}
                 <div>
        <input type="radio" value="admin" onChange={e=>setuserRole(e.target.value)} name="role" /> Admin &nbsp;
        <input type="radio" value="mentor" onChange={e=>setuserRole(e.target.value)} name="role" /> Mentor &nbsp;
        <input type="radio" value="student" onChange={e=>setuserRole(e.target.value)} name="role" /> Student &nbsp;
      </div><br></br>
     
            <button data-tip data-for="registerHelp" className="btn btn-primary btn-lg" onClick={handleSubmit}>Register</button>
            &emsp;&emsp;<Link to={`/`}><button className="btn btn-warning btn-lg">Back</button></Link>
            &emsp;&emsp;<Link to={`/`} style={{'fontSize':'15px'}}>Already Registered Click here to Login</Link><br></br>
            <hr></hr>
        </form>
    )
}
export default Register;