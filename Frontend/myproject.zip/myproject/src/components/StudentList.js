import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import ReactTooltip from 'react-tooltip';
import StudentService from '../Service/StudentService';
import { PencilFill,Person,Trash,PersonBadge } from 'react-bootstrap-icons';

const StudentList = () => {

  const [students, setStudents] = useState([]);
  const [tempStud,setTempStud] = useState([]);
  const [searchtext, setSearchtext] = useState("");
  const [searchBy, setSearchBy] = useState("");
  const [inst, setInst] = useState(false);
  const [flag, setFlag] = useState(0);
  const [mapFlag, setMapFlag] = useState(true);
  const {name} = useParams();
  
  const [dealFlag,setDealFlag] = useState(true);
  const option =['First Name','Email','Id'];
  useEffect(()=>{toggleDealFlagTrue()},[])
  const toggleDealFlagTrue=()=>{setTimeout(()=>{setDealFlag(true); toggleDealFlagFalse()},3000)}
  const toggleDealFlagFalse=()=>{setTimeout(()=>{setDealFlag(false); toggleDealFlagTrue()},3000)}

  const giveInstructions=()=>
  {
    if(flag==0 && searchBy==="")
    {
      setInst(true);
      setFlag(1);
    }
     
  }

  const hideInstructions=()=>
  {
      setInst(false);
  }
  const filterOption=(e)=>{
    console.log(e.target.studentFirstName);
    setSearchBy(e.target.value);
  }

  const populateList=()=>
  {
    if(searchBy===option[0])
    setTempStud(students.filter((stud)=>{return stud.studentFirstName.toLowerCase().includes(searchtext.toLowerCase())}));
    if(searchBy===option[1])
    setTempStud(students.filter((stud)=>{return stud.studentEmail.toLowerCase().includes(searchtext.toLowerCase())}));
    if(searchBy===option[2])
    setTempStud(students.filter((stud)=>{return stud.studentId===parseInt(searchtext)}))
    if(searchtext==="")
    setTempStud(students);
  } 
  useEffect(()=>{
     populateList();
  },[searchtext])
 

  const init = () => 
  {
    StudentService.getAll().then(response => 
      {
        console.log('Printing student data', response.data);
        setStudents(response.data);
         setTempStud(response.data);
       
       
        console.warn(response.data);
      })
      .catch(error => 
      {
        console.log('Something went wrong', error);
      }) 
  }

  useEffect(() => {
    init();
    
  }, []);
  const setMapArray=()=>{

  }

  const handleDelete = (id) => {
    var del = window.confirm("Are you Confirm");
    if(!del)
    return;
    console.log('Printing id', id);
    StudentService.remove(id)
      .then(response => {
        console.log('Student deleted successfully', response.data);

        init();
       

      })
      .catch(error => {
        console.log('Something went wrong', error);
      })
  }

  return (
    <div >
      <select name='search'  value={searchBy} onChange={(e)=>filterOption(e)} style={{'width':'150px','height':'40px','borderRadius':'7px','fontSize':'20px','backgroundColor':'skyblue'}}>
        <option >Search by</option>
        <option value={option[0]} >{option[0]}</option>
        <option value={option[1]} >{option[1]}</option>
        <option value={option[2]} >{option[2]}</option>
      </select>
       &emsp;&emsp;
     {/*   <p> {inst ? <p style={{'background':'orange','width':'300px','fontWeight':'bolder'}}>Change filter criteria from here</p>:<p></p> }</p> */}

      <input placeholder='Serach'  onChange={(e)=>setSearchtext(e.target.value)} onFocus={giveInstructions} onBlur={hideInstructions} style={{'width':'300px','height':'40px'}}></input>&emsp;
      
     {/*  <ReactTooltip id='show' type='error' delayShow={300} delayUpdate={500}>Click to Search  { students.map((stud)=> {return <p>{stud.studentId}&emsp;{stud.studentFname} &emsp;</p>})}   </ReactTooltip>  */}
      <button data-tip data-for="show" className='btn btn-primary' onClick={populateList}>Search</button>
      
      &emsp;&emsp;&emsp;&emsp;&emsp;

      &emsp; {/* {dealFlag ? <p style={{'backgroundColor':'red','width':'200px'}}>You selected : {searchBy}</p> : <p>You can change it</p>} */}
      <h3>List of Students</h3>
      <hr/>
      <div>
        <Link to="/add" className="btn btn-primary mb-2">Add Students</Link>
        <table className="table table-bordered table-striped">
          <thead className="thead-dark">
            <tr>
              
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Mobile No</th>
              <th>DOB</th>
              <th>Gender</th>
              {/*<th>Assigned Course</th>*/}
             {/* <th>Password</th> */}
              <th>Action</th>
              
            </tr>
          </thead>
          
          <tbody>
          { 
            tempStud.map(student => (
              <tr key={student.studentId}>
             {/*   <td><Link to={`/uploadImage/${employee.id}`}><img src={`http://localhost:8080/api/employees/${employee.id}/image`} style={{'height':'50px','width':'50px'}}></img></Link></td> */}
                <td>{student.studentFirstName}</td>
                <td>{student.studentLastName}</td>
                <td>{student.studentEmail}</td>
                <td>{student.studentMobileNo}</td>
                <td>{student.studentDob}</td>
                <td>{student.studentGender}</td>
              {/*  <td>{student.assignedStudentCourse}</td> */}
              {/*  <td>{student.studentPassword}</td> */}
              
                <td>
                 {/*  <ReactTooltip id={`editData${student.studentId}`}>Click to Edit Record</ReactTooltip>  */}
                 {/*  <ReactTooltip id={`editPic${student.studentId}`}>Click to Edit Picture</ReactTooltip>
                  */}{/*  <ReactTooltip id={`delete${student.studentId}`}>Click to Delete Record</ReactTooltip>
                  <ReactTooltip id={`multipleImage${student.studentId}`}>Click to Upload multiple picture </ReactTooltip> */}
                  <Link  to={`/students/edit/${student.studentId}`}><PencilFill size='25px' data-tip data-for={`editData${student.studentId}`}></PencilFill></Link>
                 &nbsp;&nbsp; {/* <Link  to={`/uploadImage/${student.studentId}`}><Person size='25px' data-tip data-for={`editPic${student.studentId}`}></Person></Link> */}
                 &emsp; <Trash data-tip data-for={`delete${student.studentId}`} size='25px' style={{'color':'red','cursor':'pointer'}}  onClick={() => {
                    handleDelete(student.studentId);
                  }}></Trash>&emsp;&emsp;
               {/*  <Link to={`/multipleImage/${student.studentId}`}><PersonBadge size='25px' data-tip data-for={`multipleImage${student.studentId}`}></PersonBadge></Link>  */}
                </td>
              </tr>
            ))
                 }
          </tbody>
                
        </table>
       <br></br><br></br>
      {/*  <Link to={`/manipulatestudent`}><button className='btn btn-danger btn-lg'>Manipulate Student List</button></Link> */}
        &emsp;&emsp;&emsp;&emsp;<Link to={`/admin`}><button className='btn btn-warning btn-lg'>Back</button></Link>
      </div>
    </div>
  );
}

export default StudentList;
