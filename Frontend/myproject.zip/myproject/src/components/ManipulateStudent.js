import axios from "axios";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ReactTooltip from "react-tooltip";

const PerformOperation=()=>
{
    const [students, setStudents] = useState([]);
    const [list, setList] = useState([]);
    const [search, setSearch] = useState(0);
    const [searchBy,setSearchBy] = useState('');
    const [place,setPlace] = useState('');
    const option =['Salary','Department Location','Increment Salary'];
    const getEmpList=()=>axios.get(`http://localhost:8080/api/employees/greatersalary/${search}`,{headers:{"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}}).then(respone=>setEmployees(respone.data)).catch(err=>console.log(err));
    const getEmpListByDeptLoc=(dept,loc)=>axios.get(`http://localhost:8080/api/employees/get/${dept}/${loc}`,{headers:{"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}}).then(respone=>setEmployees(respone.data)).catch(err=>console.log(err));
    const updateEmpSalary=(dept,sal)=>axios.put(`http://localhost:8080/api/employees/update/${dept}/${sal}`,{headers:{"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}}).then(respone=>alert(respone.data+" record updated")).catch(err=>console.log(err));
    const filterOption=(event)=>{
        setSearchBy(event.target.value)
        

    }
    const getAllList=()=>axios.get(`http://localhost:8080/api/employees`,{headers:{"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}}).then(res=>setList(res.data));
    useEffect(()=>{getAllList()},[])
    useEffect(()=>{
      if(searchBy===option[0])
        setPlace('Enter Salary to see list of Employees greater than Entered Salary');
      if(searchBy===option[1])
        setPlace("Enter first Deparment name and then Location separated by space to see list")
      if(searchBy===option[2])
        setPlace("Enter Department name and Salary increment amount to update salary of that department")
      if(searchBy==='notSelected')
        setPlace('');
    },[searchBy])
    
    const performOpration=()=>{
        if(search!=="")
        if(searchBy===option[0])
        getEmpList();
        if(searchBy===option[1])
            {
                const arr = search.split(" ");
                const dept = arr[0];
                const loc = arr[1];
               getEmpListByDeptLoc(dept,loc);
            }
            if(searchBy===option[2])
            {
                const arr = search.split(" ");
                const dept = arr[0];
                const sal = arr[1];
                // alert(dept+"  "+sal);
                var c = window.confirm("Are you Confirm?  Department : "+dept+",  Salary increment : "+sal)
                if(!c)
                return;
                updateEmpSalary(dept,sal);
            }
    }
     useEffect(()=>{},[employees])
    return(
        <div>
          <ReactTooltip id="emplist"><p>
            <table style={{'borderSpacing':'10px'}}><thead><th>EmpId</th>&emsp;<th>FirstName</th>&emsp;<th> Department </th>&emsp;<th>Salary</th></thead></table>
              </p>
             {list.map((emp)=>{return <p><td>{emp.id}&emsp;</td><td>{emp.fname}&emsp;</td><td>{emp.department}&emsp;</td><td>{emp.salary}</td></p>})}</ReactTooltip>
           
            <select data-tip data-for='emplist' name='searchtext'  value={searchBy} onChange={(e)=>filterOption(e)} style={{'width':'250px','height':'40px','borderRadius':'7px','fontSize':'20px','backgroundColor':'skyblue'}}>
        <option value='notSelected'>Modify By</option>
        <option value={option[0]} >{option[0]}</option>
        <option value={option[1]} >{option[1]}</option>
        <option value={option[2]} >{option[2]}</option>
      </select>&emsp; <input value={search} onChange={(e)=>setSearch(e.target.value)} style={{'width':'300px','height':'40px'}} ></input>{/* <button onClick={getEmpList}>Search By Salary</button> */}
            &emsp;&emsp; <p style={{'background':'yellow','width':'900px','fontWeight':'bolder','marginLeft':'400px'}}>{place}</p><button onClick={performOpration} className='btn btn-danger btn-lg'>Perform</button>
            <h3>List of Employees</h3>
      <hr/>
      <div> 
        <Link to="/add" className="btn btn-primary mb-2">Add Employee</Link>
        <table className="table table-bordered table-striped">
          <thead className="thead-dark">
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Location</th>
              <th>Department</th>
              <th>Join Date</th>
              <th>Salary</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          {
            employees.map(employee => (
              <tr key={employee.id}>
                
                <td>{employee.fname}</td>
                <td>{employee.lname}</td>
                <td>{employee.email}</td>
                <td>{employee.location}</td>
                <td>{employee.department}</td>
                <td>{employee.jdate}</td>
                <td>{employee.salary}</td>
                <td>
                 
                </td>
              </tr>
            ))
          }
          </tbody>
        </table>
        </div>
        <Link to={`/list`}><button className="btn btn-primary">Back</button></Link>
        </div>
    )
}
export default PerformOperation;