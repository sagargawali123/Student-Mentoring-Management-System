import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import ReactTooltip from 'react-tooltip';
import CourseService from '../Service/CourseService';
import { PencilFill,Person,Trash,PersonBadge } from 'react-bootstrap-icons';

const CourseList = () => {

  const [courses, setCourses] = useState([]);
  const [tempCourse,setTempCourse] = useState([]);
  const [searchtext, setSearchtext] = useState("");
  const [searchBy, setSearchBy] = useState("");
  const [inst, setInst] = useState(false);
  const [flag, setFlag] = useState(0);
  const [mapFlag, setMapFlag] = useState(true);
  const {name} = useParams();
  
  const [dealFlag,setDealFlag] = useState(true);
  const option =['Course Name',' Course Id'];
  useEffect(()=>{toggleDealFlagTrue()},[])
  const toggleDealFlagTrue=()=>{setTimeout(()=>{setDealFlag(true); toggleDealFlagFalse()},1000)}
  const toggleDealFlagFalse=()=>{setTimeout(()=>{setDealFlag(false); toggleDealFlagTrue()},1000)}

  const giveInstructions=()=>
  {
    if(flag==0 && searchBy==="")
    {
      setInst(true);
      setFlag(1);
    }
     
  }

  const hideInstructions=()=>
  {
      setInst(false);
  }
  const filterOption=(e)=>{
    console.log(e.target.courseName);
    setSearchBy(e.target.value);
  }

  const populateList=()=>
  {
    if(searchBy===option[0])
    setTempCourse(courses.filter((course)=>{return course.courseName.toLowerCase().includes(searchtext.toLowerCase())}));
    if(searchBy===option[1])
    setTempCourse(courses.filter((course)=>{return course.courseId===parseInt(searchtext)}));
    

    if(searchtext==="")
    setTempCourse(courses);
  } 
  useEffect(()=>{
     populateList();
  },[searchtext])
 

  const init = () => 
  {
    CourseService.getAll().then(response => 
      {
        console.log('Printing Course data', response.data);
        setCourses(response.data);
         setTempCourse(response.data);
       
       
        console.warn(response.data);
      })
      .catch(error => 
      {
        console.log('Something went wrong', error);
      }) 
  }

  useEffect(() => {
    init();
    
  }, []);
  const setMapArray=()=>{

  }

  const handleDelete = (id) => {
    var del = window.confirm("Are you Confirm");
    if(!del)
    return;
    console.log('Printing id', id);
    CourseService.remove(id)
      .then(response => {
        console.log('Course deleted successfully', response.data);

        init();
       

      })
      .catch(error => {
        console.log('Something went wrong', error);
      })
  }

  return (
    <div >
      <select name='search'  value={searchBy} onChange={(e)=>filterOption(e)} style={{'width':'150px','height':'40px','borderRadius':'7px','fontSize':'20px','backgroundColor':'skyblue'}}>
        <option >Search by</option>
        <option value={option[0]} >{option[0]}</option>
        <option value={option[1]} >{option[1]}</option>
      </select> 
       &emsp;&emsp;
      {/* <p> {inst ? <p style={{'background':'orange','width':'300px','fontWeight':'bolder'}}>Change filter criteria from here</p>:<p></p> }</p> */}

      <input placeholder='Serach'  onChange={(e)=>setSearchtext(e.target.value)} onFocus={giveInstructions} onBlur={hideInstructions} style={{'width':'300px','height':'40px'}}></input>&emsp;
      
     {/* <ReactTooltip id='show' type='error' delayShow={300} delayUpdate={500}>Click to Search  { courses.map((course)=> {return <p>{course.courseId}&emsp;{course.courseName} &emsp;</p>})}   </ReactTooltip> */}
      <button data-tip data-for="show" className='btn btn-primary' onClick={populateList}>Search</button>
      
      &emsp;&emsp;&emsp;&emsp;&emsp;

     {/* &emsp; {dealFlag ? <p style={{'backgroundColor':'red','width':'200px'}}>You selected : {searchBy}</p> : <p>You can change it</p>} */}
      <h3>List of Courses</h3>
      <hr/>
      <div>
        <Link to="/addcourse" className="btn btn-primary mb-2">Add Courses</Link>
        <table className="table table-bordered table-striped">
          <thead className="thead-dark">
            <tr>
              <th>Course Id</th>
              <th>Course Name</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Action</th>
              
            </tr>
          </thead>
          
          <tbody>
          { 
            tempCourse.map(course => (
              <tr key={course.courseId}>
             {/*   <td><Link to={`/uploadImage/${employee.id}`}><img src={`http://localhost:8080/api/employees/${employee.id}/image`} style={{'height':'50px','width':'50px'}}></img></Link></td> */}
                <td>{course.courseId}</td>
                <td>{course.courseName}</td>
                <td>{course.startDate}</td>
                <td>{course.endDate}</td>
              
                <td>
               {/*   <ReactTooltip id={`editData${course.courseId}`}>Click to Edit Record</ReactTooltip> */}
                 {/* <ReactTooltip id={`editPic${course.courseId}`}>Click to Edit Picture</ReactTooltip> */}
                {/*  <ReactTooltip id={`delete${course.courseId}`}>Click to Delete Record</ReactTooltip> */}
               {/*   <ReactTooltip id={`multipleImage${course.courseId}`}>Click to Upload multiple picture </ReactTooltip> */}
                  <Link  to={`/course/edit/${course.courseId}`}><PencilFill size='25px' data-tip data-for={`editData${course.courseId}`}></PencilFill></Link>
              {/*   &nbsp;&nbsp; <Link  to={`/uploadImage/${course.courseId}`}><Person size='25px' data-tip data-for={`editPic${course.courseId}`}></Person></Link> */}
                 &emsp; <Trash data-tip data-for={`delete${course.courseId}`} size='25px' style={{'color':'red','cursor':'pointer'}}  onClick={() => {
                    handleDelete(course.courseId);
                  }}></Trash>&emsp;&emsp;
               {/* <Link to={`/multipleImage/${course.courseId}`}><PersonBadge size='25px' data-tip data-for={`multipleImage${course.courseId}`}></PersonBadge></Link> */}
                </td>
              </tr>
            ))
                 }
          </tbody>
                
        </table>
       <br></br><br></br>
      {/*  <Link to={`/manipulatestudent`}><button className='btn btn-danger btn-lg'>Manipulate Student List</button></Link> */}
        &emsp;&emsp;&emsp;&emsp;<Link to={`/admin`}><button className='btn btn-warning btn-lg'>Back</button></Link>
      </div>
    </div>
  );
}

export default CourseList;
