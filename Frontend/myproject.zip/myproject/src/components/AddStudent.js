import axios from "axios";
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";
import StudentService from "../Service/StudentService";


const AddStudent = () => {
    const[studentFirstName, setstudentFirstName] = useState('');
    const [studentLastName, setstudentLastName] = useState('');
    const [studentEmail, setstudentEmail] = useState('');
    const [studentPassword, setstudentPassword] = useState('');
    const [studentMobileNo, setstudentMobileNo] = useState('');
    const [studentDob, setstudentDob] = useState('');
    const[studentGender, setstudentGender] = useState('');
    const[studentMarks, setstudentMarks] = useState('');
    const[assignedStudentCourse,setassignedStudentCourse]=useState('');
    const[studentAddress,setstudentAddress]=useState('');
    const[assignedMentor,setassignedMentor]=useState('');

    const navigate = useNavigate();
    const {id} = useParams();

    
    const saveStudent = (s) => {
        s.preventDefault();
        
        const student = {studentFirstName, studentLastName,studentEmail,studentPassword,studentMobileNo, studentDob, studentGender, studentMarks,assignedStudentCourse,studentAddress,assignedMentor,id};
        if (id) {
            //update
            console.log(student);
            StudentService.update(id,student)
                .then(response => {
                    console.log('Student data updated successfully', response.data);
                    navigate('/liststudent');
                })
                .catch(error => {
                    alert(error.response.status);
                    console.log("Error code "+error);
                    console.log('Something went wrong', error.response.data);
                   
                }) 
        } else {
            //create
            console.log(student);
             StudentService.create(student)
            .then(response => {
                console.log("Student added successfully", response.data);
                navigate("/liststudent");
            })
            .catch(error => {
                // console.log(error.response.data);
                // alert(error.response.data.Worklocation);
                // console.log(error.response.headers)
                // console.log(error.response.status);
                console.log('something went wrong'+ error.response);
            })
        }
    }

    useEffect(() => {
        if (id) {
            StudentService.get(id)
                .then(student => {
                    setstudentFirstName(student.data.studentFirstName);
                    setstudentLastName(student.data.studentLastName);
                    setstudentEmail(student.data.studentEmail);
                    setstudentPassword(student.data.studentPassword);
                    setstudentMobileNo(student.data.studentMobileNo)
                    setstudentDob(student.data.studentDob);
                    setstudentGender(student.data.studentGender);
                    setstudentMarks(student.data.studentMarks);
                    setassignedStudentCourse(student.data.assignedStudentCourse);
                    setstudentAddress(student.data.studentAddress);
                    setassignedMentor(student.data.assignedMentor);
                   
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                })
        }
    }, 
    [])
    return(
        <div className="container">
            <h3>Add Student</h3>
            <hr/>
            <form style={{'width':'500px'}}>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="studentFirstName"
                        value={studentFirstName}
                        onChange={(e) => setstudentFirstName(e.target.value)}
                        placeholder="Enter first name"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="studentLastName"
                        value={studentLastName}
                        onChange={(e) => setstudentLastName(e.target.value)}
                        placeholder="Enter last name"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="studentEmail"
                        value={studentEmail}
                        onChange={(e) => setstudentEmail(e.target.value)}
                        placeholder="Enter email"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="password" 
                        className="form-control col-6"
                        id="studentPassword"
                        value={studentPassword}
                        onChange={(e) => setstudentPassword(e.target.value)}
                        placeholder="Enter Password"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="studentMobileNo"
                        value={studentMobileNo}
                        onChange={(e) => setstudentMobileNo(e.target.value)}
                        placeholder="Enter Mobile no"
                    />

                </div>
                <div className="mb-3">
                    <p align="left">Enter DOB</p>
                    <input 
                        type="date" 
                        className="form-control col-6"
                        id="studentDob"
                        value={studentDob}
                        onChange={(e) => setstudentDob(e.target.value)}
                        placeholder="Enter DOB"
                    />
                </div>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="studentGender"
                        value={studentGender}
                        onChange={(e) => setstudentGender(e.target.value)}
                        placeholder="Enter Gender"
                    />

                </div>
                {/*
                <div className="mb-3">
                    <input 
                        type="number" 
                        className="form-control col-6"
                        id="studentMarks"
                        value={studentMarks}
                        onChange={(e) => setstudentMarks(e.target.value)}
                        placeholder="Enter marks"
                    />
                
                </div>
                */}
                {/*
                <div className="mb-3">
                    <input 
                        type="number" 
                        className="form-control col-6"
                        id="assignedStudentCourse"
                        value={assignedStudentCourse}
                        onChange={(e) => setassignedStudentCourse(e.target.value)}
                        placeholder="Enter course ID"
                    />

                </div>
                */}
                {/*
                <div className="mb-3">
                    <input 
                        type="number" 
                        className="form-control col-6"
                        id="studentAddress"
                        value={studentAddress}
                        onChange={(e) => setstudentAddress(e.target.value)}
                        placeholder="Enter Address ID"
                    />

                </div>
                */}
                {/*
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="assignedMentor"
                        value={assignedMentor}
                        onChange={(e) => setassignedMentor(e.target.value)}
                        placeholder="Enter Mentor ID"
                    />

                </div>
                */}
                   
                
                    <button onClick={(s) => saveStudent(s)} className="btn btn-warning btn-lg">Save</button>
                
            </form>
            <hr/>
            <Link to="/liststudent">Back to List</Link> &emsp;&emsp;&emsp;&emsp;{/*<Link to={`/admin`}>&emsp;&emsp;<button className='btn btn-warning btn-lg'>Go to Admin Page</button></Link>*/}
        </div>
    )
}

export default AddStudent;