 const Header=()=>{
     return(
         <div>
             <br></br>
    <h1  class="font-weight-bold">Student Mentoring Management System</h1>
         </div>
     )
 }
// export default Header;
// const Header = (props) => {
//     return (
//       <div className="container header">
//         <h3>{props.title} </h3>
//       </div>
//     );
//   };
  export default Header;
  