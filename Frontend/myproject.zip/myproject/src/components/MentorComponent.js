import { Link, useNavigate, useParams } from "react-router-dom";
import AuthenticateSevice from "../Service/AuthenticationService";

const Mentor=()=>{
    
    const [msg, setMsg] = ('');
    const navigate = useNavigate('');
   //  const {mentorEmail} = useParams();
     const user=JSON.parse(localStorage.getItem("user"));
     console.log(user);

    const testJWT=()=>{
        AuthenticateSevice.checkUser().then(response=>alert("success")).catch(error=>alert("error"));
    }

    const logOut=()=>{
        var log = window.confirm("Do you want to logout");
        if(!log)
        return;
        localStorage.removeItem("user");
        navigate(`/`);
    }

    return(
    
    <div>
            <h1 style={{'color':'orange'}}>Mentor Login Successful</h1> <br /><br />
            <h1 style={{'backgroundColor':'skyblue','width':'400px','marginLeft':'500px'}}>Hello  {user.mentorFirstName} </h1>
           
           <br /><br />
           {/*}
           <ReactTooltip id='jwtHelp'>Click to call API by sending JWT :
                <p style={{'color':'red'}}> {JSON.parse(localStorage.getItem("user"))}</p>           
           </ReactTooltip>

           <ReactTooltip id='jwtHelpLogOut'>When you LogOut this JWT token deletes from Local Storage , you can see it from application browser tab :
                <p style={{'color':'red'}}> {JSON.parse(localStorage.getItem("user"))}</p>           
           </ReactTooltip>
    */}
          {/*   <button data-tip data-for='jwtHelp' onClick={testJWT} className='btn btn-success'>Test JWT</button>&emsp;&emsp;&emsp;&emsp; */}
            <Link to={`/listassignedstudent/${user.mentorId}`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Assigned Students List</button></Link>&emsp;&emsp;&emsp;
           {/* <Link to={`/listmentor`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Go to Mentor List</button></Link>&emsp;&emsp;&emsp; */}
            <Link to={`/admindetails`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Admin Details</button></Link>&emsp;&emsp;&emsp; 
          {/*  <Link to={`/listcourse`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">All Courses List</button></Link>&emsp;&emsp;&emsp; */}
            <Link to={`/singlecourse/${user.mentorId}`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Assigned Course Details</button></Link>
            &emsp; <button data-tip data-for='jwtHelpLogOut' className="btn btn-danger btn-lg" onClick={logOut}>Log Out</button>&emsp;&emsp;&emsp;&emsp;&emsp;
            <br></br>
            <br></br>
            <br></br>
           {/* <Link to={`/sendEmail`}><button className="btn btn-primary">Send Email</button></Link>  */}
        </div>
    
    );
};


export default Mentor;