import axios from "axios";
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";
import MentorService from "../Service/MentorService";


const AddMentor = () => {
    const[mentorFirstName, setmentorFirstName] = useState('');
    const [mentorLastName, setmentorLastName] = useState('');
    const [mentorEmail, setmentorEmail] = useState('');
    const [mentorPassword, setmentorPassword] = useState('');
    const [mentorMoNo, setmentorMoNo] = useState('');
    const [batchSize, setbatchSize] = useState('');
    const[currentBatchSize, setcurrentBatchSize] = useState('');
    const[mentorDob, setmentorDob] = useState('');
    const[mentorGender,setmentorGender]=useState('');
    const[mentorJoinYear,setmentorJoinYear]=useState('');
    const[avgRating,setavgRating]=useState('');
 //  const[mentorAddress,setmentorAddress]=useState('');
 //   const[assignedMentorCourseId,setassignedMentorCourseId]=useState('')

    const navigate = useNavigate();
    const {id} = useParams();

    
    const saveMentor = (s) => {
        s.preventDefault();
        
        const mentor = {id,mentorFirstName, mentorLastName,mentorEmail,mentorPassword,mentorMoNo, batchSize, currentBatchSize, mentorDob,mentorGender,mentorJoinYear,avgRating};
        if (id) {
            //update
            console.log(mentor);
            MentorService.update(id,mentor)
                .then(response => {
                    console.log('Student data updated successfully', response.data);
                    navigate('/listmentor');
                })
                .catch(error => {
                    alert(error.response.status);
                    console.log("Error code "+error);
                    console.log('Something went wrong', error.response.data);
                   
                }) 
        } else {
            //create
            console.log(mentor);
             MentorService.create(mentor)
            .then(response => {
                console.log("Student added successfully", response.data);
                navigate("/listmentor");
            })
            .catch(error => {
                // console.log(error.response.data);
                // alert(error.response.data.Worklocation);
                // console.log(error.response.headers)
                // console.log(error.response.status);
                console.log('something went wrong'+ error.response);
            })
        }
    }

    useEffect(() => {
        if (id) {
            MentorService.get(id)
                .then(mentor => {
                    setmentorFirstName(mentor.data.mentorFirstName);
                    setmentorLastName(mentor.data.mentorLastName);
                    setmentorEmail(mentor.data.mentorEmail);
                    setmentorPassword(mentor.data.mentorPassword);
                    setmentorMoNo(mentor.data.mentorMoNo)
                    setbatchSize(mentor.data.batchSize);
                    setcurrentBatchSize(mentor.data.currentBatchSize);
                    setmentorDob(mentor.data.mentorDob);
                    setmentorGender(mentor.data.mentorGender);
                    setmentorJoinYear(mentor.data.mentorJoinYear);
                    setavgRating(mentor.data.avgRating);
                 //   setmentorAddress(mentor.data.mentorAddress);
                  //  setassignedMentorCourseId(mentor.data.assignedMentorCourseId);

                   
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                })
        }
    }, 
    [])
    return(
        <div className="container">
            <h3>Add Mentor</h3>
            <hr/>
            <form style={{'width':'500px'}}>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="mentorFirstName"
                        value={mentorFirstName}
                        onChange={(e) => setmentorFirstName(e.target.value)}
                        placeholder="Enter first name"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="mentorLastName"
                        value={mentorLastName}
                        onChange={(e) => setmentorLastName(e.target.value)}
                        placeholder="Enter last name"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="mentorEmail"
                        value={mentorEmail}
                        onChange={(e) => setmentorEmail(e.target.value)}
                        placeholder="Enter email"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="password" 
                        className="form-control col-6"
                        id="mentorPassword"
                        value={mentorPassword}
                        onChange={(e) => setmentorPassword(e.target.value)}
                        placeholder="Enter Password"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="mentorMoNo"
                        value={mentorMoNo}
                        onChange={(e) => setmentorMoNo(e.target.value)}
                        placeholder="Enter Mobile no"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="number" 
                        className="form-control col-6"
                        id="batchSize"
                        value={batchSize}
                        onChange={(e) => setbatchSize(e.target.value)}
                        placeholder="Enter batch size"
                    />
                </div>
                <div className="mb-3">
                    <input 
                        type="number" 
                        className="form-control col-6"
                        id="currentBatchSize"
                        value={currentBatchSize}
                        onChange={(e) => setcurrentBatchSize(e.target.value)}
                        placeholder="Enter current batch size"
                    />

                </div>
                
                
                    
                
                
                <div className=" mb-3 ">
                
                <p align="left">Enter DOB</p>
                    <input 
                        type="date" 
                        className="form-control col-6"
                        id="mentorDob"
                        value={mentorDob}
                        onChange={(e) => setmentorDob(e.target.value)}
                        placeholder="Enter Dob"
                    />
                    
                </div>
                <div className="mb-3">
                    <input 
                        type="text" 
                        className="form-control col-6"
                        id="mentorGender"
                        value={mentorGender}
                        onChange={(e) => setmentorGender(e.target.value)}
                        placeholder="Enter Gender"
                    />

                </div>
                <div className="mb-3">
                <p align="left">Enter Joining Year</p>
                    <input 
                        type="date" 
                        className="form-control col-6"
                        id="mentorJoinYear"
                        value={mentorJoinYear}
                        onChange={(e) => setmentorJoinYear(e.target.value)}
                        placeholder="Enter Join date"
                    />

                </div>
                <div className="mb-3">
                    <input 
                        type="number" 
                        className="form-control col-6"
                        id="avgRating"
                        value={avgRating}
                        onChange={(e) => setavgRating(e.target.value)}
                        placeholder="Enter Avg Rating"
                    />

                </div>
                {/*
                <div className="mb-3">
                    <input 
                        type="number" 
                        className="form-control col-6"
                        id="mentorAddress"
                        value={mentorAddress}
                        onChange={(e) => setmentorAddress(e.target.value)}
                        placeholder="Enter mentor address"
                    />

                </div>
                */}
                {/*
                <div className="mb-3">
                    <input 
                        type="number" 
                        className="form-control col-6"
                        id="assignedMentorCourseId"
                        value={assignedMentorCourseId}
                        onChange={(e) => setassignedMentorCourseId(e.target.value)}
                        placeholder="Enter mentor course id"
                    />

                </div>
                */}
                   
                
                    <button onClick={(s) => saveMentor(s)} className="btn btn-warning btn-lg">Save</button>
                
            </form>
            <hr/>
            <Link to="/listmentor">Back to List</Link> &emsp;&emsp;&emsp;&emsp;{/*<Link to={`/admin`}>&emsp;&emsp;<button className='btn btn-warning btn-lg'>Back</button></Link> */}
        </div>
    )
}

export default AddMentor;