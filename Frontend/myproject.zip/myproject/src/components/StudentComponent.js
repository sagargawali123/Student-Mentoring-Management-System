import { Link, useNavigate, useParams } from "react-router-dom";
import AuthenticateSevice from "../Service/AuthenticationService";
const Student=()=>{
    const [msg, setMsg] = ('');
    const navigate = useNavigate('');
    // const {studentFirstName} = useParams();
    const user=JSON.parse(localStorage.getItem("user"));
    console.log(user);
    const testJWT=()=>{
        AuthenticateSevice.checkUser().then(response=>alert("success")).catch(error=>alert("error"));
    }

    const logOut=()=>{
        var log = window.confirm("Do you want to logout");
        if(!log)
        return;
        localStorage.removeItem("user");
        navigate(`/`);
    }

    return(
    
    <div>
            <h1 style={{'color':'green'}}>Student Login Successful</h1> <br /><br />
            <h1 style={{'backgroundColor':'skyblue','width':'400px','marginLeft':'500px'}}>Hello  {user.studentFirstName} </h1>
           
           <br /><br />
           {/*}
           <ReactTooltip id='jwtHelp'>Click to call API by sending JWT :
                <p style={{'color':'red'}}> {JSON.parse(localStorage.getItem("user"))}</p>           
           </ReactTooltip>

           <ReactTooltip id='jwtHelpLogOut'>When you LogOut this JWT token deletes from Local Storage , you can see it from application browser tab :
                <p style={{'color':'red'}}> {JSON.parse(localStorage.getItem("user"))}</p>           
           </ReactTooltip>
    */}
          {/*   <button data-tip data-for='jwtHelp' onClick={testJWT} className='btn btn-success'>Test JWT</button>&emsp;&emsp;&emsp;&emsp; */}
           {/* <Link to={`/liststudent`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Go to Student List</button></Link>&emsp;&emsp;&emsp; */}
            <Link to={`/listassignedmentor/${user.studentId}`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Assigned Mentor Details</button></Link>&emsp;&emsp;&emsp;
            <Link to={`/admindetailsforstudent`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Admin Details</button></Link>&emsp;&emsp;&emsp; 
            <Link to={`/singlecourseforstudent/${user.studentId}`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Assigned Course Details</button></Link>
          {/*  <Link to={`/listcourse`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Go to Course List</button></Link>&emsp;&emsp;&emsp; */}
            &emsp; <button data-tip data-for='jwtHelpLogOut' className="btn btn-danger btn-lg" onClick={logOut}>Log Out</button>&emsp;&emsp;&emsp;&emsp;&emsp;
           {/* <Link to={`/sendEmail`}><button className="btn btn-primary">Send Email</button></Link>  */}
           <br></br>
           <br></br>
           <br></br>
           <br></br>
        </div>
    
    );
};


export default Student;