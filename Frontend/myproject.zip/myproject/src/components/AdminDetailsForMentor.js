import React, { Component } from "react";

import AdminService from "../Service/AdminService";
import { Link } from "react-router-dom";

class AdminDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      adminDetails: "",
    };
  }

  componentDidMount() {
    AdminService.getAdminDetailsByAdminId(this.props.data1).then((response) => {
      this.setState({ adminDetails: response.data });
    });
  }

  render() {
    return (
      <div>
        <div className="greetingsProfileCard">
            <center className="greetingsProfileInfo">
              <p style={{ fontSize: "20px" }}>
                Admin Profile Information:
              </p>
            </center>
          </div>
        <div className="card text-white bg-dark mb-3 adminProfileCard">
          <div className="card-body">
            <div className="container">
              <br />
              <p className="card-text">
                Admin Name :-  Sagar Gawali{this.state.adminDetails.adminEmail}{" "}
              </p>
              <p className="card-text">
                Admin Email :- sagar@gamil.com {this.state.adminDetails.adminDob}{" "}
              </p>
              <p className="card-text">
                Contact No :- 9668554565{this.state.adminDetails.adminGender}{" "}
              </p>
            </div>
            <br></br>
            <Link to={`/mentor`}><button data-tip data-for='jwtHelp' className="btn btn-warning btn-lg">Back</button></Link>&emsp;&emsp;&emsp; 
          </div>
        </div>
      </div>
    );
  }
}

export default AdminDetails;
