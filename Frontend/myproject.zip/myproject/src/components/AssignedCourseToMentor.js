import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import ReactTooltip from 'react-tooltip';
import MentorService from '../Service/MentorService';
import CourseService from '../Service/CourseService';
import { PencilFill,Person,Trash,PersonBadge } from 'react-bootstrap-icons';

const AssignedCourseToMentor = () => {

  const [course, setCourse] = useState("");
  const [tempCourse,setTempCourse] = useState([]);
  const [searchtext, setSearchtext] = useState("");
  const [searchBy, setSearchBy] = useState("");
  const [inst, setInst] = useState(false);
  const [flag, setFlag] = useState(0);
  const [mapFlag, setMapFlag] = useState(true);
  const {id} = useParams();
  
  const [dealFlag,setDealFlag] = useState(true);
  
/*
  const populateList=()=>
  {
    if(searchBy===option[0])
    //setTempMentor(mentors.filter((mentor)=>{return mentor.mentorFirstName.toLowerCase().includes(searchtext.toLowerCase())}));
    if(searchBy===option[1])
    setTempMentor(mentors.filter((mentor)=>{return mentor.mentorEmail.toLowerCase().includes(searchtext.toLowerCase())}));
    if(searchBy===option[2])
    setTempMentor(mentors.filter((mentor)=>{return mentor.mentorId===parseInt(searchtext)}))
    if(searchtext==="")
    setTempMentor(mentors);
  }
  */ 
  useEffect(()=>{
  //   populateList();
  },[searchtext])
 

  const init = (id) => 
  {
    CourseService.getCourseDetailByMentorId(id).then(response => 
      {
        console.log('Printing mentor data', response.data);
        setCourse(response.data);
         setTempCourse(response.data);
       
       
        console.warn(response.data);
      })
      .catch(error => 
      {
        console.log('Something went wrong', error);
      }) 
  }

  useEffect(() => {
    init(id);
    
  }, []);
  const setMapArray=()=>{

  }

  const handleDelete = (id) => {
    var del = window.confirm("Are you Confirm");
    if(!del)
    return;
    console.log('Printing id', id);
    MentorService.remove(id)
      .then(response => {
        console.log('Mentor deleted successfully', response.data);

        init();
       

      })
      .catch(error => {
        console.log('Something went wrong', error);
      })
  }

  return (
    <div >
        {/*
      <select name='search'  value={searchBy} onChange={(e)=>filterOption(e)} style={{'width':'150px','height':'40px','borderRadius':'7px','fontSize':'20px','backgroundColor':'skyblue'}}>
        <option >Search by</option>
        <option value={option[0]} >{option[0]}</option>
        <option value={option[1]} >{option[1]}</option>
        <option value={option[2]} >{option[2]}</option>
      </select>
        */}
       &emsp;&emsp;
     {/*   <p> {inst ? <p style={{'background':'orange','width':'300px','fontWeight':'bolder'}}>Change filter criteria from here</p>:<p></p> }</p> */}

    {/*  <input placeholder='Serach'  onChange={(e)=>setSearchtext(e.target.value)} onFocus={giveInstructions} onBlur={hideInstructions} style={{'width':'300px','height':'40px'}}></input>&emsp; */}
      
     {/*  <ReactTooltip id='show' type='error' delayShow={300} delayUpdate={500}>Click to Search  { students.map((stud)=> {return <p>{stud.studentId}&emsp;{stud.studentFname} &emsp;</p>})}   </ReactTooltip>  */}
    {/*  <button data-tip data-for="show" className='btn btn-primary' onClick={populateList}>Search</button> */}
      
      &emsp;&emsp;&emsp;&emsp;&emsp;

      &emsp; {/* {dealFlag ? <p style={{'backgroundColor':'red','width':'200px'}}>You selected : {searchBy}</p> : <p>You can change it</p>} */}
      <h3> Assigned Course Details</h3>
      <hr/>
      <br></br>
      <div>
      {/*  <Link to="/addmentor" className="btn btn-primary mb-2">Add Mentors</Link> */}
        <table className="table table-bordered table-striped">
          <thead className="thead-dark">
            <tr>
              <th>Course Id</th>
            <th>Course Name</th>
              <th>Start Date</th>
              <th>End Date</th>

              
              
            {/*  <th>Address</th> */}
            {/*  <th>Assigned Course</th> */}
              
              
            </tr>
          </thead>
          
          <tbody>
          { 
          //  mentors.map(mentor => (

              <tr key={course.courseId}>
             {/*   <td><Link to={`/uploadImage/${employee.id}`}><img src={`http://localhost:8080/api/employees/${employee.id}/image`} style={{'height':'50px','width':'50px'}}></img></Link></td> */}
                <td>{course.courseId}</td>
                <td>{course.courseName}</td>
                <td>{course.startDate}</td>
                <td>{course.endDate}</td>
                
          {/*      <td>{mentor.mentorAddress}</td> */}
           {/*     <td>{mentor.assignedMentorCourseId}</td> */}
              
                
                 {/*  <ReactTooltip id={`editData${student.studentId}`}>Click to Edit Record</ReactTooltip>  */}
                 {/*  <ReactTooltip id={`editPic${student.studentId}`}>Click to Edit Picture</ReactTooltip>
                  */}{/*  <ReactTooltip id={`delete${student.studentId}`}>Click to Delete Record</ReactTooltip>
                  <ReactTooltip id={`multipleImage${student.studentId}`}>Click to Upload multiple picture </ReactTooltip> */}
               {/*  <Link to={`/multipleImage/${student.studentId}`}><PersonBadge size='25px' data-tip data-for={`multipleImage${student.studentId}`}></PersonBadge></Link>  */}
                
              </tr>
         //   ))
                 }
          </tbody>
                
        </table>
       <br></br><br></br>
      {/*  <Link to={`/manipulatestudent`}><button className='btn btn-danger btn-lg'>Manipulate Student List</button></Link> */}
        &emsp;&emsp;&emsp;&emsp;<Link to={`/mentor`}><button className='btn btn-warning btn-lg'>Go Back</button></Link>
      </div>
      <br></br>
      <br></br>

    </div>
  );
}

export default AssignedCourseToMentor;
