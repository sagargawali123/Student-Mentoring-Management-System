import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";
import StudentService from "../Service/StudentService";
import MentorService from "../Service/MentorService";

const EditMarks =()=>{

    const user=JSON.parse(localStorage.getItem("user"));
     console.log(user);
    const[studentMarks, setstudentMarks] = useState('');
    const navigate = useNavigate();
    const {id} = useParams();

    const saveMarks=(s)=>{
        s.preventDefault();
        
        const student={studentMarks,id}
        if(id){
            console.log(student);
            MentorService.updateMarks(id,student)
            .then(response => { alert("Student Marks Updated Successfully");
                console.log('Student Marks updated successfully', response.data);
                navigate(`/listassignedstudent/${user.mentorId}`);
        })
        .catch(error => {
            alert(error.response.status);
            console.log("Error code "+error);
            console.log('Something went wrong', error.response.data);
           
        })
    }
}
useEffect(() => {
    if (id) {
        StudentService.get(id)
            .then(student => {
               setstudentMarks(student.data.studentMarks)
            })
            .catch(error => {
                console.log('Something went wrong', error);
            })
    }
}, 
[])
return(
    <div className="container">
            <br></br>
        
            <h3>Update Marks </h3>
            <hr/>
            <br></br>
            <form style={{'width':'500px'}}>
            <div className="mb-3">
                    <input 
                        type="number" 
                        className="form-control col-6"
                        id="studentMarks"
                        value={studentMarks}
                        onChange={(e) => setstudentMarks(e.target.value)}
                        placeholder="Enter marks"
                    />

                </div>
                <br></br>
                <button onClick={(s) => saveMarks(s)} className="btn btn-warning btn-lg">Save</button>
                <br></br>
                <br></br>
            </form>
            <hr/>
            <br></br>
            {/*<Link to={`/listassignedstudent/${user.mentorId}`}>Back to List</Link> */}

    </div>
)

}

export default EditMarks;