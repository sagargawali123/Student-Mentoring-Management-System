import React from "react";
import { useNavigate } from "react-router";
import { Link  } from "react-router-dom";
import { useState } from "react";
import AuthenticateSevice from "../Service/AuthenticationService";
import ReCAPTCHA from "react-google-recaptcha";

const LoginComponent=()=>{
  const [userRole,setRole] = useState('');
  const [userEmail,setEmail] = useState('');
  const [userPassword,setPassword] = useState('');
  const navigate = useNavigate();
  const [Verifed,setVerifed]=useState(false);

 function onChange(value){
 console.log("Captcha value:", value);
 setVerifed(true);

 }

  const handleSubmit=()=>
  {
      if(userRole == "admin")
      AuthenticateSevice.authenticateUser(userRole,userEmail,userPassword).then(response=>{console.log("success "+response.data);
                          // AuthenticateSevice.storeUserDetails(userName,response.data.jwt);
                          localStorage.setItem("user",JSON.stringify(response.data));
                         navigate(`/admin`)}).catch(error=>{console.log("error "+error);alert("Wrong details you have Entered")})
                  //         history.push("success").catch(error=>{console.log("error "+error);alert("Wrong details you have Entered")})
                          // localStorage.setItem('jwt',response.data.jwt)

      if(userRole == "mentor")
      AuthenticateSevice.authenticateUser(userRole,userEmail,userPassword).then(response=>{console.log("success "+response.data);
                          localStorage.setItem("user",JSON.stringify(response.data));
                          navigate(`/mentor`)}).catch(error=>{console.log("error "+error);alert("Wrong details you have Entered")})

      if(userRole == "student")
      AuthenticateSevice.authenticateUser(userRole,userEmail,userPassword).then(response=>{console.log("success "+response.data);
                          localStorage.setItem("user",JSON.stringify(response.data));
                          navigate(`/student`)}).catch(error=>{console.log("error "+error);alert("Wrong details you have Entered")})
  }
    return(
     
      <form>
          <hr></hr>
          {/*
          <select class="form-select form-select-sm mb-3" aria-label="form-select-sm example"
             onChange={e=>setRole(e.target.value)}
          >
  <option selected>Select Role</option>
  <option value="admin">Admin</option>
  <option value="mentor">Mentor</option>
  <option value="student">Student</option>
</select>
          */}
          <div><h4>Select Role</h4></div>
            <div>
        <input type="radio" value="admin" onChange={e=>setRole(e.target.value)} name="role" /> Admin &nbsp;
        <input type="radio" value="mentor" onChange={e=>setRole(e.target.value)} name="role" /> Mentor &nbsp;
        <input type="radio" value="student" onChange={e=>setRole(e.target.value)} name="role" /> Student &nbsp;
      </div><br></br>
     {/* <!-- Email input --> */}
      <div class="form-outline mb-4">
      <label class="form-label" for="">Email address</label><br></br>
        <input type="email" id="" name="email" value={userEmail}  onChange={e=>setEmail(e.target.value)} placeholder="Enter Email" class="form-control-lg" />
        
      </div>
    
     {/* <!-- Password input --> */}
      <div class="form-outline mb-4">
      <label class="form-label" for="">Password</label><br></br>
        <input type="password" id="" name="password" value={userPassword} onChange={e=>setPassword(e.target.value)} placeholder="Enter Password" class=" form-control-lg" />
        
      </div>
    
     {/* <!-- 2 column grid layout for inline styling --> */}
     {/* */}
     {/* <div class="row mb-4"> */}
        <div class="col d-flex justify-content-center">
         {/* <!-- Checkbox -->  
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="form2Example31" checked />
            <label class="form-check-label" for="form2Example31"> Remember me </label>
          </div>
         */}
        </div>
        
    {/*
        <div class="col">
        
          <a href="#!">Forgot password?</a>
        </div>
    */}
    {/*  </div> */}
    
    <div align="center">  
    <ReCAPTCHA sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI" onChange={onChange}/>,
    </div>
    <button type="button" class="btn btn-primary btn-lg mb-2" disabled={!Verifed} onClick={handleSubmit}>Sign in</button><br></br><br></br>
    
    
      <div class="text-center">
        <h5><p>Not a member? <a href="/register">Register</a></p></h5>
       
      </div>
      <hr></hr>
    </form>
    
      )
}
export default LoginComponent;