import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter as Router, Switch, Route} from "react-router-dom"
import Navbar from './components/Navbar';
import Header from './components/Header';
import Footer from "./components/FooterComponent";
import AboutComponent from './components/AboutComponent';
import ContactsComponent from './components/ContactsComponent'
import FAQComponent from './components/FAQComponent';
import LoadingComponenet from './components/LoadingComponent';
import LoginComponent from './components/LoginComponent';
import AdminComponent from './components/AdminComponent';
import MentorComponent from './components/MentorComponent';
import StudentComponent from './components/StudentComponent';
import { Routes } from 'react-router';
import StudentList from './components/StudentList';
import AddStudent from './components/AddStudent';
import CourseList from './components/CourseList';
import AddCourse from './components/AddCourse';
import MentorList from './components/MentorList';
import AddMentor from './components/AddMentor';
import Register from './components/Register';
import AssignedMentorToStudentList from './components/AssignedMentorToStudentList';
import AssignedMentorToStudent from './components/AssignedMetorToStudent';
import EditMarks from './components/EditMarks';
import AdminDetails from './components/AdminDetailsForMentor';
//import SingleCourseDetails from './components/AssignedCourseToMentor';
import AssignedCourseToMentor from './components/AssignedCourseToMentor';
import AssignedCourseToStudent from './components/AssignedCourseToStudent';
import AdminDetailsForStudent from './components/AdminDetailsForStudent';

function App() {
  return (
    <div className="App">
      
      <Router>
      <Navbar/>
      <Header/>
     {/* <LoginComponent/> */}
      
        <Routes>
        <Route path="/" element={<LoginComponent></LoginComponent>} />
        <Route path="/register" element={<Register></Register>} />
        <Route path="/about" element={<AboutComponent></AboutComponent>} />
        <Route path="/contact" element={<ContactsComponent></ContactsComponent>} />
        <Route path="/faq" element={<FAQComponent></FAQComponent>} />
        <Route path="/loading" element={<LoadingComponenet></LoadingComponenet>} />
        <Route path="/admin" element={<AdminComponent></AdminComponent>}/>
        <Route path="/mentor" element={<MentorComponent></MentorComponent>}/>
        <Route path="/student" element={<StudentComponent></StudentComponent>}/>
        <Route path="/liststudent" element={<StudentList></StudentList>}/>
        <Route path="/add/" element={<AddStudent></AddStudent>} />
        <Route path="/students/edit/:id/" element={<AddStudent></AddStudent>} />
        <Route path="/listcourse" element={<CourseList></CourseList>}/>
        <Route path="/addcourse" element={<AddCourse></AddCourse>}/>
        <Route path="/course/edit/:id/" element={<AddCourse></AddCourse>}/>
        <Route path="/listmentor" element={<MentorList></MentorList>}/>
        <Route path="/addmentor" element={<AddMentor></AddMentor>}/>
        <Route path="/mentor/edit/:id/" element={<AddMentor></AddMentor>}/>
        <Route path="/listassignedstudent/:id" element={<AssignedMentorToStudentList></AssignedMentorToStudentList>}/>
        <Route path="/listassignedmentor/:id" element={<AssignedMentorToStudent></AssignedMentorToStudent>}/>
        <Route path="/students/editmarks/:id" element={<EditMarks></EditMarks>}/>
        <Route path="/admindetails" element={<AdminDetails></AdminDetails>} />
        <Route path="/singlecourse/:id" element={<AssignedCourseToMentor></AssignedCourseToMentor>}/>
        <Route path="/singlecourseforstudent/:id" element={<AssignedCourseToStudent></AssignedCourseToStudent>}/>
        <Route path="/admindetailsforstudent" element={<AdminDetailsForStudent></AdminDetailsForStudent>}/>
        </Routes>
        <Footer/>   
      </Router>
     
    </div>
  );
}

export default App;
