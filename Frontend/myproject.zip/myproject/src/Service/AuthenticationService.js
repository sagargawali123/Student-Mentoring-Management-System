import axios from 'axios';
class AuthenticationService {
  authenticateUser(userRole,userEmail, userPassword) {
    //make api call for auth 
    console.log('auth call', userRole,userEmail, userPassword);
    return axios.post('http://localhost:8080/user/signin', {
      userRole:userRole,
      userEmail: userEmail,
      userPassword: userPassword,
    });
  }
/*
  registerUser=(userFirstName,userLastName,userEmail,userPassword,userMoNo,regDate,userRole)=>{
    console.log(userFirstName,userLastName,userEmail,userPassword,userMoNo,regDate,userRole);
    return axios.post('http://localhost:8080/user/register',{
      userFirstName:userFirstName,
      userLastName:userLastName,
      userEmail:userEmail,
      userPassword:userPassword,
      userMoNo:userMoNo,
      regDate:regDate,
      userRole:userRole,
    });
  }
  */

  registerUser=(user)=>{
    return axios.post('http://localhost:8080/user/register',user);
  }
}
export default new AuthenticationService();