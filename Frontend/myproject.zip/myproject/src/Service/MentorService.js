
import httpClient from '../http-mentor';
const getAll = () => {
    return httpClient.get('',{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`} });
  };
  const create = (data) => {
    return httpClient.post('', data,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  };

const get = (id) => {
    return httpClient.get(`/${id}`,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  };
  const update = (id,data) => {
    return httpClient.put(`/${id}`, data,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  };
  
  const remove = (id) => {
    return httpClient.delete(`/${id}`,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  };
  const assignedStduents=(id)=>{
    return httpClient.get(`assignedStudents/${id}`);
  };
  const updateMarks=(id,data)=>{
    return httpClient.put(`/updateMarks/${id}`,data,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  }
  export default { getAll, create, get, update, remove,assignedStduents,updateMarks };
  
 