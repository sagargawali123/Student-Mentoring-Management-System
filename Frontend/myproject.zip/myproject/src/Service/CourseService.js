import httpClient from '../http-course';
const getAll = () => {
    return httpClient.get('',{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`} });
  };
  const create = (data) => {
    return httpClient.post('', data,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  };

const get = (id) => {
    return httpClient.get(`/${id}`,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  };
  const update = (id,data) => {
    return httpClient.put(`/${id}`,data,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  };
  
  const remove = (id) => {
    return httpClient.delete(`/${id}`,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  };
  // to get single course detail by MentorId
  const getCourseDetailByMentorId=(MentorId)=> {
    return httpClient.get( `mentorcourse/${MentorId}`,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  }
  // to get single course detail by StudentId
  const getCourseDetailByStudentId=(StudentId)=> {
    return httpClient.get( `studentcourse/${StudentId}`,{ headers: {"Authorization" : `Bearer ${JSON.parse(localStorage.getItem("user"))}`}});
  }
  export default { getAll, create, get, update, remove,getCourseDetailByStudentId,getCourseDetailByMentorId };